﻿/* 1/27/2020
 * CSC 153
 * Silvia McCartney
 * The program loads and displays given values 
 * Solution Name-TotalSalesHardCoded
 */
using System;
namespace TotalSales
{
    class Program
    {
        static void Main(string[] args)
        {
            double[] numbers = { 1245.67, 1189.55, 1098.72, 1456.88, 2109.34, 1987.55, 1872.36 };
            for (int x = 0; x <=6; x++)
            {
                Console.WriteLine(numbers[x]);
                
            }
            
        }
    }
}
