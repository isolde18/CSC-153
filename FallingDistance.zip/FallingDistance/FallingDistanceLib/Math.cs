﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// THIS IS THE LIBRARY CLASS
namespace FallingDistanceLib
{
    public class Math
    {
        public static double MultiplyNumbers (double input)
        {
            //double d = input ; //ask the user for falling time in seconds
            double output = input * 0.5 * 9.8;//* math.Pow(t, 2);
            return output;
        }
        public static double SquareNumbers(double d)
        {
             double output= d *Math.SquareNumbers( 2.0);//throws exception  
            return output;
        }

    }
}


