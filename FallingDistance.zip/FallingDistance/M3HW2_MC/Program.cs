﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*2-23-2020
 * CSC 153
 * Silvia
 * an application that allows the user to enter 
 * the amount of time that and object has fallen
 * and then display the distance the object fell
 * 
 */
 //THIS IS THE MAIN METHOD
namespace M3HW2_MC
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Console.ReadLine();
            //call the methods from the calculations class
            calculations.DisplayFallingDistance();
            double d = 0;
            // Console.WriteLine(FallingDistanceLib.Math.MultiplyNumbers(d));
            Console.WriteLine(FallingDistanceLib.Math.MultiplyNumbers(FallingDistanceLib.Math.SquareNumbers(d)));
        }
    }
}
