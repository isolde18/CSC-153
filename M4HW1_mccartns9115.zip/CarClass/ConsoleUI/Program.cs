﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
 CSC 153
 Silvia
 McCartney
 3/22/2020
 Car Class 
Speed - create 2 methods for getAccel and getBrake
Accelerate - The Accelerate method should add 5 to the Speed property
Brake - The Brake method should subtract 5 from the Speed property
The application should give the user 4 options,
1. Create car, 2. Accelerate, 3. Brake, 4.Exit.
After creating a car object if the user chooses
Accelerate or brake, 
the application should display the car's new speed. 

 */
namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            do
            {
                Console.WriteLine("Enter your choice, from 1 to 4.\n"
                   + "1.Create a car\n2.Accelarate\n3.Brake\n4.Exit");
                string choice = Console.ReadLine();
                Console.WriteLine("Enter your choice, from 1 to 4.\n"
                   + "1.Create a car\n2.Accelarate\n3.Brake\n4.Exit");
                switch (choice)
                {
                    case "1":
                        Console.WriteLine("You entered:1.Create a car.");
                        Car mycar = new Car("Toyota", 2013, 0);
                        Console.WriteLine(mycar.Make);
                        Console.WriteLine(mycar.Year);
                        Console.WriteLine(mycar.Speed);
                        mycar.Speed = 0;
                        Console.ReadLine();
                        break;
                    case "2":
                        int nextSpeed = 5; 
                        Console.WriteLine("You choose:2.Accelarate ");
                        Console.WriteLine("The speed is:" + nextSpeed);
                        break;
                    case "3":
                        Console.WriteLine("You entered:3.Brakes");
                        int pressingBrake = 0;
                        Console.WriteLine("Your car speed is: " +
                            pressingBrake);
                        break;
                    case "4":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Please Enter a Valid Choice");
                        break;
                }
            } while (exit == false);
        }
    }
}