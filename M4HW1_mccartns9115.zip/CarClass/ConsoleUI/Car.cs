﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    public class Car
    {
        private string _carMake;
        private int _yearMade;
        private int _carSpeed;

        public Car(string aCarMake, int aYearMade, int aCarSpeed)
        {
            _carMake = aCarMake;
            _yearMade = aYearMade;
            _carSpeed = aCarSpeed;
            _carSpeed = 0;

        }
        public string Make
        {
            get { return _carMake; }
            set { _carMake = value; }
        }
        public int Year
        {
            get { return _yearMade; }
            set { _yearMade = value; }
        }
        public int Speed
        {
            get { return _carSpeed; }
            set { _carSpeed = value; }
        }

        public void Accel()
        {
            int nextSpeed = Speed += 5;
            Console.WriteLine("The new speed is " + nextSpeed);
        }

        public void Brake(int Speed)
        {
            //if-else statement here
            if (Speed >= 5)
            {
                int brakes = Speed -= 5;//dont allow the speed to go below 0
                Console.WriteLine("The current car speed is " + brakes);
            }
            else
            {

                Console.WriteLine("");
            }

        }
    }
}









    
