﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M3HW2_MC
{
    class calculations
    {
        public static void DisplayFallingDistance()
        {
            //Console.Write("The number of calculation for the falling distance is --> ");
            Console.WriteLine("Please enter time in seconds --> ");
            double t = Convert.ToDouble(Console.ReadLine());
            Console.Write("The number of calculation for the falling distance is --> ");

            const double g = 9.8;
            const double c = .5;
            double squared = Math.Pow((t * g), 2.0);
            double d = c * squared;

            Console.WriteLine(d.ToString());
            
        }
    }
}