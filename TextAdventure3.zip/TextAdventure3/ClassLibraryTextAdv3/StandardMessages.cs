﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryTextAdv3
{
   public static class StandardMessages
    {
        public static string DisplayMenu()
        {
            return "1. Enter Player's Information \n2. Display Player's Information \n3. Display Average Player Health \n4. Exit Program." +
                "\nPlease Enter a 1/2/3/4 ----> ";
        }

        public static string GetPlayerName()
        {
            return "Enter The Player's Name ----> ";
        }

        public static string GetPlayerPhoneNum()
        {
            return "Enter The Player's Phone Number ----> ";
        }
       
        public static string GetPlayerHealth()
        {
            return "Enter The Player's Health ----> ";
        }
        public static string GetPlayerPassword()
        {
            return "Enter The Player's Password ----> ";
        }



        public static string DisplayGoodbye()
        {
            return "Have a nice day";
        }

        public static string CleaningCode()
        {
            return " ";
        }

        public static string DisplayMenuError()
        {
            return "Error! Not a valid menu choice!";
        }

        public static string DisplayHealthError()
        {
            return "Must have at least 5 health to play";
        }

    }
}

    

