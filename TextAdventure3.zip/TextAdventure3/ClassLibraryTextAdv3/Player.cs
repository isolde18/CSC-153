﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryTextAdv3
{
    public class Player
    {
        // Fields
        private string _name;
        private string _phoneNumber;
        private int _health;
        private string _password;

        // Constructers
        public Player()
        {
            Name = "No Name";
            PhoneNumber = "No Phone";
            Health = 0;
            Password = "";//
        }

        public Player(string name, string phone, int health, string password)
        {
            Name = name;
            PhoneNumber = phone;
            Health = health;
            Password ="";
        }
        // Properties
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }

        public string PhoneNumber
        {
            get
            {
                return _phoneNumber;
            }
            set
            {
                _phoneNumber = value;
            }
        }

        public int Health
        {
            get
            {
                return _health;
            }
            set
            {
                _health = value;
            }
        }
        public string Password
        {
            get
            {
                return _password;
            }
            set
            {
                _password= value;
            }
        }

        // Methods
    }
}


    

