﻿using System;
using System.Collections.Generic;
using ClassLibraryTextAdv3;
namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            //Create sentry for loop
            bool exit = false;

            //Create a List for the player's health. 
            List<Player> health = new List<Player>();

            do
            {
                //Calling the menu void method to display to the user and get back input
                Console.WriteLine(StandardMessages.DisplayMenu());

                //Creating the Decision Structure (Switch) to direct proper process
                switch (Console.ReadLine())
                {
                    case "1":
                        //Calling the void method GetPlayerName
                        BuildPlayer.BuildPlayers(health);
                        break;
                    case "2":
                        //Passing each array and list and calling the display method. 
                        DisplayPlayer.DisplayPlayerInfo(health);
                        Console.WriteLine(StandardMessages.CleaningCode());
                        break;
                    case "3":
                        //Passing playerHealth list and calling the DisplayAverage Method. 
                        DisplayPlayer.DisplayAverageHealth(health);
                        Console.WriteLine(StandardMessages.CleaningCode());
                        break;

                    case "4":
                        //Calling the display goodbye void method
                        Console.WriteLine(StandardMessages.DisplayGoodbye());
                        Console.WriteLine(StandardMessages.CleaningCode());
                        exit = true;
                        break;
                    default:
                        Console.WriteLine(StandardMessages.DisplayMenuError());
                        break;


                }

            } while (exit == false);


        }
    }
}

