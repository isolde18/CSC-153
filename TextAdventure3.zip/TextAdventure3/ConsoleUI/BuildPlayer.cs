﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibraryTextAdv3;

namespace ConsoleUI
{
    public static class BuildPlayer
    {
        public static void BuildPlayers(List<Player> inputList)
        {
            bool correct = false;

            Player output = new Player();

            Console.WriteLine(StandardMessages.GetPlayerName());
            output.Name = Console.ReadLine();

            Console.WriteLine(StandardMessages.GetPlayerPhoneNum());
            output.PhoneNumber = Console.ReadLine();

            Console.WriteLine(StandardMessages.GetPlayerPassword());
            output.Password = Console.ReadLine();

            do
            {
                Console.WriteLine(StandardMessages.GetPlayerHealth());
                output.Health = TryParse.ParseToInt(Console.ReadLine());

                if (output.Health >= 5)
                {
                    correct = true;
                }
                else
                {
                    Console.WriteLine(StandardMessages.DisplayHealthError());
                }

            } while (correct == false);

            inputList.Add(output);
        }
    }
}
