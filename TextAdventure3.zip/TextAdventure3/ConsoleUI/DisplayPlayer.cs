﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibraryTextAdv3;

namespace ConsoleUI
{
   public static  class DisplayPlayer
    {
        public static void DisplayPlayerInfo(List<Player> inputList)
        {
            foreach (var player in inputList)
            {
                Console.WriteLine($"Player - {player.Name} Phone - {player.PhoneNumber} Health - {player.Health} Password -{player.Password}");
            }
        }

        public static void DisplayAverageHealth(List<Player> inputList)
        {
            int health = 0;
            double average = 0.0;

            foreach (var player in inputList)
            {
                health += player.Health;
            }
            average = health / inputList.Count();


            Console.WriteLine(average);
        }
    }
}
