﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            string input;
            bool exit = false;
            //create constatnt Var
            const int SIZE = 5;

            int nameIndex = 0, phoneIndex = 0, ageInfo = 0;
            string[] employeeNames = new string[SIZE];
            string[] employeePhone = new string[SIZE];
            List<int> employeeAge = new List<int>();

            do
            {
                Console.WriteLine("1.Enter employee's name.");
                Console.WriteLine("2. Enter employee's phone number.");
                Console.WriteLine("3.Enter employee's age.");
                Console.WriteLine("4. Display employee information.");
                Console.WriteLine("5. Display average age of employees.");
                Console.WriteLine("6.Exit");
                Console.Write("-->");
                input = Console.ReadLine();

                //Switch to direct to proper process
                switch(input)
                {
                    case "1":
                        Console.WriteLine("Enter employee's name -> ");
                        input = Console.ReadLine();
                        employeeNames[nameIndex]= input;
                        nameIndex++;
                        break;
                        
                    case "2":
                        Console.WriteLine("Enter employee's Phone number ->");
                        input =Console.ReadLine();
                        employeePhone[phoneIndex]=input;
                        phoneIndex++;
                        Console.WriteLine();
                        break;
                    case "3":
                        int number = 0;
                        Console.WriteLine("Enter employees age ->");
                        input = Console.ReadLine();
                        employeeAge.Add(number);
                        if (int.TryParse(input, out number))
                        {
                            employeeAge.Add(number);
                        }
                        else
                        {
                            Console.WriteLine("Not a valid number!");
                        }
                        Console.WriteLine();
                        break;
                    case "4":
                        for (int index=0; index< employeeAge.Count; index++)
                        {
                            Console.WriteLine($"Employee name - {employeeNames[index]}");
                            Console.WriteLine($"Employee Phone - {employeePhone[index]}");
                            Console.WriteLine($"Employee Age - {employeeAge[index]}");
                            
                        }
                        Console.WriteLine();
                        break;
                    case "5":
                        Console.WriteLine(employeeAge.Average());
                        break;
                    case "6":
                        exit = true;
                        break;                        
                    default:
                        Console.WriteLine("Not a valid choice!");
                        break;



                }

            } while (exit == false); 
            
        }
    }
}
