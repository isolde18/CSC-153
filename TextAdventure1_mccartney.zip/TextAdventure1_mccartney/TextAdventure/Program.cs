﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
2/17/2020
CSC 153
Silvia
This program is supposes to have a menu with 4 arrays for 5 rooms, 4 weapons, 2 Potions and 3 tresure (4)
    and 2 lists for 4 items and 5 mobs ( menu 5. and 6.) and (7) exit.
*/
namespace TextAdventure
{
    class Program
    {
        static void Main(string[] args)
        {
            string input;
            bool exit = false;
            //const int SIZE = 0;
            //List <int> items = new List<int>() {0,1,2,3};//list items
            //Console.WriteLine("-->");
           
            //Console.WriteLine($"There are {items.Count} items in the project");
            //    for (int index=0;index<items.Count();index++)
            //{
            //    Console.WriteLine($"Item {items[index]}");
            //}
            //Console.WriteLine("-->");

            //List<int> mobs = new List<int>() { 0, 1, 2, 3, 4 };//lists mobs
            //Console.WriteLine($"There are {mobs.Count} mobs in the project");
            //    for (int index = 0; index < mobs.Count(); index++)
            //{
            //    Console.WriteLine($"Mobs --> {mobs[index]}");
            //}

            // create 4 arrays for 5, 4, 2 and 3 elements

            do
            {
               
                Console.WriteLine("1.Display rooms"); //array
                Console.WriteLine("2.Display weapons"); //array
                Console.WriteLine("3.Display potions"); //array
                Console.WriteLine("4.Display treasures"); //array
                Console.WriteLine("5.Display items"); // list
                Console.WriteLine("6.Display mobs"); // list
                Console.WriteLine("7.Exit");
                Console.Write("-->");

                input = Console.ReadLine();

                switch (input)
                {

                    case "1":

                        Console.WriteLine("Display the rooms ");
                        // Step 1: Array Declaration 
                        string[] string_room;

                        // Step 2:Array Initialization 
                        string_room = new string[5] { "Room_1", "Room_2", "Room_3", "Room_4", "Room_5" };

                        // Step 3:Accessing Array Elements 
                        Console.WriteLine(string_room[0]);
                        Console.WriteLine(string_room[1]);
                        Console.WriteLine(string_room[2]);
                        Console.WriteLine(string_room[3]);
                        Console.WriteLine(string_room[4]);
                        break;
                        
                    case "2":

                        Console.WriteLine("Display the weapons ");
                        string[] string_weapons;
                        string_weapons = new string[4] { "W1", "W2", "W3", "W4"};
                        Console.WriteLine(string_weapons[0]);
                        Console.WriteLine(string_weapons[1]);
                        Console.WriteLine(string_weapons[2]);
                        Console.WriteLine(string_weapons[3]);
                        
                         break;
                    case "3":

                        Console.WriteLine("Display the potions ");
                        string[] string_potions;
                        string_potions = new string[2] { "P1", "P2" };
                        Console.WriteLine(string_potions[0]);
                        Console.WriteLine(string_potions[1]);

                       break;
                    case "4":

                        Console.WriteLine("Display the treasures ");
                        // array initialization and declaration in single line 
                        String[] string_treasures = new String[] { "T1", "T2", "T3" };

                        // accessing array elements 
                        Console.WriteLine(string_treasures[0]);
                        Console.WriteLine(string_treasures[1]);
                        Console.WriteLine(string_treasures[2]);
                        
                        break;

                    case "5":

                        Console.WriteLine("Display the items ");

                        List<int> items = new List<int>() { 0, 1, 2, 3 };//list items
                        Console.WriteLine("-->");

                        Console.WriteLine($"There are {items.Count} items in the project");
                        for (int index = 0; index < items.Count(); index++)
                        {
                            Console.WriteLine($"Item {items[index]}");
                        }
                        Console.WriteLine("-->");

                        break;

                    case "6":

                        Console.WriteLine("Display the mobs ");

                        List<int> mobs = new List<int>() { 0, 1, 2, 3, 4 };//lists mobs
                        Console.WriteLine($"There are {mobs.Count} mobs in the project");
                        for (int index = 0; index < mobs.Count(); index++)
                        {
                            Console.WriteLine($"Mob {mobs[index]}");
                        }

                        break;

                    case "7":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Not a valid choice!");
                        
                        break;
                }

                } while (exit == false);



        } 
    }
}
