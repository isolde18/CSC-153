﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace age_list
{
    class Program
    {
        static void Main(string[] args)
        {
            string UserInput;
            bool exit = false;
       //const int SIZE = 5;
        //  List<int> personChoice = new List<int>();
         List<int>age= new List<int>();
            List<int> ageList = new List<int>();
            //const int SIZE = NumberOfAges;
            // int NumberOfAgesIndex = 0;


             do
            {
                Console.WriteLine("1. Press 1 if you want to run the age program.");
                Console.WriteLine("Press 2 if you want to exit the program.");
                Console.WriteLine("2. Exit");
                Console.Write("-->");
                UserInput = Console.ReadLine();
                switch (UserInput)
                {
                    case "1":
                        int number = 0;
                        Console.WriteLine("How many ages do you want to enter? ");
                     UserInput= Console.ReadLine();
                        Console.WriteLine("Enter the ages.");
                        UserInput = Console.ReadLine();
                        //agesListIndex++;
                        //    Console.WriteLine();

                        if (int.TryParse(UserInput, out number))
                        {
                            ageList.Add(1);
                            ageList.Add(2);
                            ageList.Add(3);
                            ageList.Add(4);
                            ageList.Add(5);
                            //  Console.WriteLine($" {UserInput[number]}");//exception
                        }
                        else
                        {
                            Console.WriteLine("Not a valid number!");
                        }
                        Console.WriteLine();
                        for (number = 0; number <= age.Count; number++)
                        {

                        //  Console.WriteLine($" {UserInput[age]}");
                            Console.WriteLine();
                            //Console.WriteLine("Enter the ages.");
                            //ageList=0;
                            for (number = 0; number < ageList.Count; number++)
                        // for (int index = 0; index < UserInput.Count; index++)
                        //   for (int index=0; index<UserInput.Count; index++)
                        {

                            Console.WriteLine($" {ageList[number]}");
                        }   


                                
                        //        int[] ageList = (0, 1, 2, 3, 4, 5, 6);

                        //    for (int x = 0; x <= 6; x++)
                        //    {
                        //        Console.WriteLine(ageList[x]);
                        //    }

                        //    Console.WriteLine();
                        //}
                     }
                        break;



                    case "2":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("exit");
                        break;



                }


            } while (exit == false);
        }
    }
}


    

