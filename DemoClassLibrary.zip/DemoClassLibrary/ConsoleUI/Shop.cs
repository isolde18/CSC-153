﻿namespace ConsoleUI
{
    public class Shop
    {
        private string _item;
        private int _unitsOnHand;
        private double _price;

        public Shop(string Item, int UnitsOnHand, double Price)
        {
            _item = Item;
            _unitsOnHand = UnitsOnHand;
            _price = Price;
        }

        public string Item { 
         get {return _item;}
         set { _item = value; }
        }
        public int UnitsOnHand 
        {
           get {return _unitsOnHand; }
            set { _unitsOnHand = value; }
        
        }
       
        public double Price
        {
            get {return _price; }
            set { _price = value; }
        }

    }
}
