﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Retail
    {
        private string _item;
        private int _unitsOnHand;
        private double _price;

        public Retail(string Item, int UnitsOnHand, double Price)
        {
            _item = Item;
            _unitsOnHand = UnitsOnHand;
            _price = Price;
        }

        public string Item
        {
            get { return _item; }
            set { _item = value; }
        }
        public int UnitsOnHand
        {
            get { return _unitsOnHand; }
            set { _unitsOnHand = value; }

        }

        public double Price
        {
            get { return _price; }
            set { _price = value; }
        }


    }
}
