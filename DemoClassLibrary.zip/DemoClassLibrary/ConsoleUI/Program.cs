﻿using System;

/*
    CSC 153
    Write a class RetailItem that holds data about an item in a retail store. 
    The class should have the following properties: Description, Units on Hand, Price
    Write a constructor that accepts arguments for each property
    The application should create a list of three RetailItem objects containing the following data
    Description, Units on Hand, Price
    Jacket, 12, $59.05
    Jeans, 40, $34.95
    Shirt, 20, $24.95
*/

namespace ConsoleUI 
{
    class Program
    {
        static void Main(string[] args)
        {
            Shop myshop = new Shop("jacket", 12, 59.05);
            Console.WriteLine(myshop.Item);
            Console.WriteLine(myshop.UnitsOnHand);
            Console.WriteLine(myshop.Price);
            Console.ReadLine();
            //the first object 
            Retail myretail = new Retail("jeans", 40, 34.95);
            Console.WriteLine(myretail.Item);
            Console.WriteLine(myretail.UnitsOnHand);
            Console.WriteLine(myretail.Price);
            Console.ReadLine();
            //the second object 
            Object myobject = new Object("shirt", 20, 24.95);
            Console.WriteLine(myobject.Item);
            Console.WriteLine(myobject.UnitsOnHand);
            Console.WriteLine(myobject.Price);
            Console.ReadLine();
            //the third object 
        }
    }
}
