﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
 * CSC 153
 * Silvia
 * McCartney
 * This program takes the wholesale cost of an item and its markup percentage 
 * from the user and after then calculates the item's retail price.
 * So if an item's cost is $5.00 and its markup percentage is 50 percent, 
 * then the item's retail price is $7.50.
 **/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Enter the whole sale cost of the product: ");
            int b_cost = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter the mark up percentage in decimal format: ");
            //for 100 % enter 1.00 and for 50 % enter 0.50; 
            double x;
            double.TryParse(Console.ReadLine(), out x);

            Console.WriteLine("The mark up price is: ");
            double z = (b_cost * x);
            Console.Write(z); //5 * 0.25=1.25
            //int x = int.Parse(Console.ReadLine());
            //Console.WriteLine("Calculate the total price: ");
            //Console.ReadLine();
            double result;
            Console.WriteLine("\nThe final price is: ");
            Console.Write((b_cost + z)); /// b_cost);;
            double.TryParse(Console.ReadLine(), out result);

        }
    }
}            
           
            
            

        
    

