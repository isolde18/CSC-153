﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/**
* 4/27/2020
* CSC 153
* Silvia McCartney
* Program description
* Preferred Customer Calculation Discount
*/
namespace ConsoleUI
{
    public class PreferredCustomer : Customer
    {
       

        public PreferredCustomer(string name, string address, string phone, string number, string mail,
            string id, int spentAmount, bool mailing_list)
            : base(name, address, phone, number, mail, mailing_list)
        {
            CustomerID = id;
            SpentAmount = spentAmount;

        }
        public string CustomerID { get; set; }
        public int SpentAmount { get; set; }
        public void spentAmount()
        {
            int amount;
            Console.WriteLine("Enter the amount spent :");
             Console.ReadLine();
            amount = int.Parse(Console.ReadLine());
            switch (amount)
            {
                case 500:
                    //do
                    double result = 500 * 0.05;
                    Console.WriteLine("You spent 500 dollars and your 5% discount is : " + result + " $");
                    Console.ReadLine();
                    break;
                case 1000:
                    //do calculations
                    result = 1000 * 0.06;
                    Console.WriteLine("You spent 1000 dollars and you receive 6% discount, which is :" + result + " $");
                    Console.ReadLine();
                    break;
                case 1500:
                    //discount 
                    result = 1500 * 0.07;
                    Console.WriteLine("You spent 1500 dollars and you get 7% discount which is : " + result + " $");
                    Console.ReadLine();
                    break;
                case 2000:
                    //discount
                    result = 2000 * 0.10;
                    Console.WriteLine("You spent 2000 dollars, therefore you get 10% discount, which is : " + result + " $");
                    Console.ReadLine();
                    break;
                default:
                    Console.WriteLine("You entered an invalid choice. To be preferred customer, please re-enter one of the options above.");
                    Console.ReadLine();
                    break;

            }
        }
    }
 }
 
 
