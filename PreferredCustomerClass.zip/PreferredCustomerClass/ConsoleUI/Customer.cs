﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    public class Customer
    {

        public Customer(string name, string address, string phone, string number, string mail, bool mailing_list)
            
        {
            CustomerNumber = number;
            CustomerMail = mail;
            IsOnMailingList = mailing_list;
            CustomerName = name;
            CustomerAddress = address;
            CustomerPhone = phone;
        }
        public string CustomerNumber { get; set; }
        public string CustomerMail { get; set; }
        public bool IsOnMailingList { get; set; }
        public string CustomerName { get; set; }
        public string CustomerAddress { get; set; }
        public string CustomerPhone { get; set; }
    }
}
