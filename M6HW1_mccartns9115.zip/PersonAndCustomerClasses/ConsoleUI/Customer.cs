﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
     public class Customer : Person
    {
        public Customer()
        {
        }

        public Customer(string name, string address, string phone, string number, string mail, bool mailing_list)
           : base (name, address, phone)
        {
            CustomerNumber = number;
            CustomerMail = mail;
            isOnMailingList = mailing_list;
        }
        public string CustomerNumber { get; set; }
        public string CustomerMail { get; set; }
        public bool isOnMailingList { get; set; }
   }
}
