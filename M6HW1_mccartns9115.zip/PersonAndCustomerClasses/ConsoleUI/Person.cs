﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    public class Person
    {
        public string PersonName { get; set; }
        public string PersonAddress { get; set; }
        public string PersonPhoneNumber {get; set;}

    public Person (string name, string address, string phone)
        {
            PersonName = name;
            PersonAddress = address;
            PersonPhoneNumber = phone;
        }

        public Person()
        {
        }
    }
}
