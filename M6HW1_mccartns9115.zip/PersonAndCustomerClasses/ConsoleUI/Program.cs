﻿using System;
/*04/20/2020
 * CSC 153
 * Silvia Mccartney
 * This program display inheritance when the base class
 * is person.cs and the derived is customer cs.
 */
namespace ConsoleUI
{
    class Program
    {
        private static readonly bool isOnMailingList;

        static void Main(string[] args)
        {
            Person person = new Person();
            Customer customer = new Customer();
            person.PersonName = "Indigo Montoya";
            person.PersonAddress = "Beach Street";
            person.PersonPhoneNumber = "+1-xxx-xxx-8816";
            customer.CustomerNumber = "00001";
            Console.WriteLine($"Personal data: {person.PersonName} {person.PersonAddress} {person.PersonPhoneNumber}");
            //Console.WriteLine($"Customer info: {customer.CustomerNumber}");// {customer.isOnMailingList} 
            do
            {
                {
                    Console.WriteLine("Enter customers mailing address");
                    string customer_mail = Console.ReadLine();
                    Console.WriteLine($"Customer info: {customer.CustomerNumber}");
                    Console.WriteLine($"The mailing address is: {customer_mail}");
                }

            } while (isOnMailingList == true);
            Console.ReadLine();
        }
    }
}
