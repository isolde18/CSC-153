﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            string input;
            bool exit = false;
            //const int SIZE = 5;
           //
            //string[] age = new string[age];
            List<int> personAge = new List<int>();

            do
            {
                Console.WriteLine("1. Enter person's age.");
                //Console.WriteLine("2. Ask if you want to enter another age.");
                Console.WriteLine("3. Enter another person's age");
                //Console.WriteLine("4. How many ages do you want to enter.");
                Console.WriteLine("5. Display all the ages the user has entered.");
                Console.WriteLine("6. Exit");
                Console.Write("-->");
                input = Console.ReadLine();
                switch (input)
                {
                    case "1":
                        //List<int> personAge = new List<int>();
                        //int personAge = 0;
                        int number = 0;
                        Console.WriteLine("Enter age -> ");
                        input = Console.ReadLine();
                        personAge.Add(number);
                        if (int.TryParse(input, out number))
                        {
                            personAge.Add(number);
                        }
                        else
                        {
                            Console.WriteLine("Not a valid number!");
                        }
                        Console.WriteLine();
                        break;
                    case "3":
                        //t number = 0;
                        Console.WriteLine("Enter another person's age ->");
                        input = Console.ReadLine();
                       // personAge.Add(number);
                        if (int.TryParse(input, out number))
                        {
                           personAge.Add(number);
                        }
                        else
                        {
                            Console.WriteLine("Not a valid number!");
                        }
                        Console.WriteLine();
                        break;
                   
                    case "4":
                        for (int index = 0; index < personAge.Count; index++)
                        {
                            //Console.WriteLine($"Employee name - {employeeNames[index]}");
                            //Console.WriteLine($"Employee Phone - {employeePhone[index]}");
                            Console.WriteLine($" personAge - {personAge[index]}");

                        }
                        Console.WriteLine();
                        break;
                    case "5":
                        Console.WriteLine(personAge.Average());
                        break;
                    case "6":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Not a valid choice!");
                        break;



                }

            } while (exit == false);


        }



            }
            }
    

