﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
2/17/2020
CSC 153
Silvia
McCartney
This program is supposes to have a menu with 2 void methods and one return method 
   to allow the user to go north or south and to go combat and exit.
*/
namespace TextAdventure
{
    class Program
    {
        public static Gamer currentGamer = new Gamer();
        static void Main(string[] args)
        {
            Start();
            string input;
            bool exit = false;
           

            do
            {
               
                Console.WriteLine("1.move north");
                Console.WriteLine("2.move south"); 
                Console.WriteLine("3.attack"); 
                Console.WriteLine("4.exit"); 
                
                Console.Write("-->");

                input = Console.ReadLine();

                switch (input)
                {

                    case "1":

                       Console.WriteLine(" Display new room in numeric way starting at one");
                        // Step 1: Array Declaration 
                        string[] string_room;

                        // Step 2:Array Initialization 
                        string_room = new string[6] { "Room_1", "Room_2", "Room_3", "Room_4", "Room_5", "Room_6" };

                        // Step 3:Accessing Array Elements 
                        Console.WriteLine(string_room[0]);
                        Console.WriteLine(string_room[1]);
                        Console.WriteLine(string_room[2]);
                        Console.WriteLine(string_room[3]);
                        Console.WriteLine(string_room[4]);
                        Console.WriteLine(string_room[5]);
                        break;
                        
                    case "4":
                           exit = true;
                           break;
                        default:
                            Console.WriteLine("Not a valid choice!");
                           break;
                    case "3":

                        Console.WriteLine("Display the combat ");
                       // int genPoints=50;
                        Console.WriteLine("Enter points you have until now");//  not developed
                        string pointsUser = Console.ReadLine();
                        int num2 = Int32.Parse(pointsUser);
                        Console.WriteLine("Some hit_points to add to your points" +
                            " are depending on :.::.: where are you in the game's map");
                        string[] hit_points;
                        hit_points=new string[6] {"10", "12","14","16", "18","20"};
                        Console.WriteLine(hit_points[0]);
                        Console.WriteLine(hit_points[1]);
                        Console.WriteLine(hit_points[2]);
                        Console.WriteLine(hit_points[3]);
                        Console.WriteLine(hit_points[4]);
                        Console.WriteLine(hit_points[5]);
                        Console.WriteLine("Now towards to generete a random number:");
                        Random random = new Random();
                        int randomNumber = random.Next(1, 21);
                        int num3 = num2 - randomNumber;
                        Console.WriteLine("Your genPoints minus the generated random number is=: " + num3);
                        Console.ReadLine();
                        //you need to generate a functiom to subtract the random number from your
                        //genPoints and that has to be no less or = to 0

                        break;

                    case "2":
                        string_room = new string[6] { "Room_6", "Room_5", "Room_4", "Room_3", "Room_2", "Room_1" };
                        Console.WriteLine(string_room[0]);
                        Console.WriteLine(string_room[1]);
                        Console.WriteLine(string_room[2]);
                        Console.WriteLine(string_room[3]);
                        Console.WriteLine(string_room[4]);
                        Console.WriteLine(string_room[5]);
                        break;
                        
                }

                } while (exit == false);



        } 
        static void Start()
        {
            Console.WriteLine("Enter's dungeon!");
            Console.WriteLine("Your name: ");
            currentGamer.name=Console.ReadLine(); 
            Console.Clear();
            Console.WriteLine("Hi, your name is " +currentGamer.name);
            Console.ReadKey();
            Console.Clear();
        }
    }
}
