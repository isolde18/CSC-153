﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TextAdventure
{
    class Gamer
    {
        public string name;
        //public int coins;
        //public int health;
        //public int damage;
        //public int weapon;
        //public int potion;
       //something like that to be added
    }
}
